<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CartService — the shop's multi-item basket.
 *
 * The cart is a scratchpad: it never charges anything and never touches the
 * wallet. Prices shown here are always re-read from `marketplace_listings` at
 * render time (never trusted from the stored `quoted_unit_price`, which
 * exists only so the page renders instantly without a fresh query per row).
 * Checkout (ShopCheckoutService) re-validates every line the same way
 * MarketplaceService::purchase() already validates a single-item buy — the
 * cart does not introduce a second pricing authority.
 *
 * One open cart per user (unique key on shopping_carts.user_id) — there is no
 * multi-cart/save-for-later concept yet, matching the scope actually asked
 * for.
 */
class CartService {

    const MAX_QUANTITY_PER_LINE = 100;

    private $ci;

    public function __construct() {
        $this->ci =& get_instance();
        $this->ci->load->model(array('Cart_model', 'Cart_item_model', 'Marketplace_listing_model', 'Coupon_model'));
        $this->ci->load->library('CurrencyService');
    }

    /** The user's cart, creating an empty one if none exists yet. */
    public function cart_for($user_id) {
        return $this->ci->Cart_model->find_or_create($user_id);
    }

    /** Full cart contents plus computed totals, ready to render. */
    public function view($user_id) {
        $cart = $this->cart_for($user_id);
        $items = $this->ci->Cart_item_model->for_cart($cart->id);

        $subtotal = '0.00000000';
        $lines = array();
        $has_physical = false;
        $shipping_line_count = 0;
        $currency = marvy_base_currency();

        foreach ($items as $item) {
            $unavailable = $item->listing_status !== 'ACTIVE';
            $unit_price = $this->effective_price($item);
            $price_error = $unit_price === null;
            $line_total = ($unavailable || $price_error)
                ? '0.00000000' : bcmul($unit_price, (string)$item->quantity, 8);
            if (!$unavailable && !$price_error) $subtotal = bcadd($subtotal, $line_total, 8);

            $is_physical = strtoupper((string)$item->product_type) === 'PHYSICAL';
            // A missing physical row is deliberately not treated as a free
            // pickup. The admin form promises that a physical listing has a
            // SKU before it is sold; checkout reports the incomplete row and
            // refuses to charge it in ShopCheckoutService::validate().
            $physical_details_missing = $is_physical
                && (empty($item->physical_product_id) || trim((string)($item->physical_sku ?? '')) === '');
            $requires_shipping = $is_physical
                && !$physical_details_missing
                && (int)($item->requires_shipping ?? 1) === 1;
            if ($requires_shipping) {
                $has_physical = true;
                $shipping_line_count++;
            }

            $lines[] = array(
                'item' => $item,
                'unit_price' => $price_error ? '0.00000000' : $unit_price,
                'line_total' => $line_total,
                'unavailable' => $unavailable,
                'price_error' => $price_error,
                'out_of_stock' => $item->stock !== null && (int)$item->stock < (int)$item->quantity,
                'is_physical' => $is_physical,
                'requires_shipping' => $requires_shipping,
                'physical_details_missing' => $physical_details_missing,
            );
        }

        $coupon = null;
        $discount = '0.00000000';
        if (!empty($cart->coupon_code)) {
            // Re-validated against THIS customer and THIS subtotal every time
            // the cart is rendered or charged — not just when the code was
            // typed. Two rules were only ever checked at apply time:
            //
            //   · the per-customer usage cap, which nothing enforced at all;
            //   · the minimum spend, so a customer could apply a coupon that
            //     needed a ₦100 basket, remove everything down to ₦5 and still
            //     be charged the discounted total.
            $res = $this->ci->Coupon_model->find_valid($cart->coupon_code, $cart->user_id);
            $meets_minimum = $res && ($res->min_order_amount === null
                || bccomp($subtotal, (string)$res->min_order_amount, 8) >= 0);
            if ($res && $meets_minimum) {
                $coupon = $res;
                $discount = $this->compute_discount($res, $subtotal);
            }
        }

        $total = bcsub($subtotal, $discount, 8);
        if (bccomp($total, '0', 8) < 0) $total = '0.00000000';

        return array(
            'cart' => $cart,
            'lines' => $lines,
            'subtotal' => $subtotal,
            'discount' => $discount,
            'coupon' => $coupon,
            'total' => $total,
            'currency' => $currency,
            'has_physical' => $has_physical,
            'shipping_line_count' => $shipping_line_count,
            'count' => count($lines),
        );
    }

    /** How many distinct lines are in the cart — for a header badge. */
    public function count_for($user_id) {
        $cart = $this->ci->Cart_model->for_user($user_id);
        if (!$cart) return 0;
        return $this->ci->Cart_item_model->count_for_cart($cart->id);
    }

    /** Add (or update the quantity of) one listing in the cart. */
    public function add($user_id, $listing_public_id, $quantity = 1) {
        $listing = $this->ci->Marketplace_listing_model->find_public($listing_public_id, true);
        if (!$listing) return $this->err('NO_LISTING', 'That listing is not available.');

        $quantity = max(1, min(self::MAX_QUANTITY_PER_LINE, (int)$quantity));
        if ($listing->stock !== null && $listing->stock < $quantity) {
            return $this->err('OUT_OF_STOCK', 'Only '.(int)$listing->stock.' left in stock.');
        }

        $cart = $this->cart_for($user_id);
        $existing = $this->ci->Cart_item_model->find_in_cart($cart->id, $listing->id);
        $new_quantity = $existing ? min(self::MAX_QUANTITY_PER_LINE, (int)$existing->quantity + $quantity) : $quantity;

        $unit_price = $this->effective_price_of($listing);
        if ($unit_price === null) {
            return $this->err('CURRENCY_RATE_MISSING',
                'This item cannot be priced in '.marvy_base_currency().' yet. Ask staff to set the '.strtoupper((string)($listing->currency ?? '')).' exchange rate.');
        }

        $this->ci->Cart_item_model->upsert($cart->id, $listing->id, $new_quantity, $unit_price);
        $this->ci->Cart_model->touch($cart->id);
        return array('ok' => true, 'listing' => $listing);
    }

    /** Set an exact quantity (0 removes the line). */
    public function set_quantity($user_id, $listing_public_id, $quantity) {
        $listing = $this->ci->Marketplace_listing_model->find_public($listing_public_id, false);
        if (!$listing) return $this->err('NO_LISTING', 'That listing was not found.');

        $cart = $this->cart_for($user_id);
        $quantity = (int)$quantity;
        if ($quantity <= 0) {
            $this->ci->Cart_item_model->remove($cart->id, $listing->id);
            $this->ci->Cart_model->touch($cart->id);
            return array('ok' => true, 'removed' => true);
        }
        $quantity = min(self::MAX_QUANTITY_PER_LINE, $quantity);
        if ($listing->stock !== null && $listing->stock < $quantity) {
            return $this->err('OUT_OF_STOCK', 'Only '.(int)$listing->stock.' left in stock.');
        }
        $unit_price = $this->effective_price_of($listing);
        if ($unit_price === null) {
            return $this->err('CURRENCY_RATE_MISSING',
                'This item cannot be priced in '.marvy_base_currency().' yet. Ask staff to set the '.strtoupper((string)($listing->currency ?? '')).' exchange rate.');
        }

        $this->ci->Cart_item_model->upsert($cart->id, $listing->id, $quantity, $unit_price);
        $this->ci->Cart_model->touch($cart->id);
        return array('ok' => true);
    }

    public function remove($user_id, $listing_public_id) {
        $listing = $this->ci->Marketplace_listing_model->find_public($listing_public_id, false);
        if (!$listing) return $this->err('NO_LISTING', 'That listing was not found.');
        $cart = $this->cart_for($user_id);
        $this->ci->Cart_item_model->remove($cart->id, $listing->id);
        $this->ci->Cart_model->touch($cart->id);
        return array('ok' => true);
    }

    /** Apply a coupon code to the cart. Validity is re-checked at checkout too. */
    public function apply_coupon($user_id, $code) {
        $code = strtoupper(trim((string)$code));
        if ($code === '') return $this->err('NO_CODE', 'Enter a coupon code.');
        $coupon = $this->ci->Coupon_model->find_valid($code);
        if (!$coupon) return $this->err('INVALID_COUPON', 'That coupon is not valid or has expired.');
        if (!$this->ci->Coupon_model->within_user_limit($coupon, $user_id)) {
            return $this->err('ALREADY_USED', 'You have already used this coupon.');
        }

        $view = $this->view($user_id);
        if ($coupon->min_order_amount !== null && bccomp($view['subtotal'], $coupon->min_order_amount, 8) < 0) {
            return $this->err('BELOW_MINIMUM', 'This coupon requires a subtotal of at least '.marvy_money($coupon->min_order_amount).'.');
        }

        $cart = $this->cart_for($user_id);
        $this->ci->Cart_model->set_coupon($cart->id, $code);
        return array('ok' => true);
    }

    public function remove_coupon($user_id) {
        $cart = $this->cart_for($user_id);
        $this->ci->Cart_model->set_coupon($cart->id, null);
        return array('ok' => true);
    }

    /**
     * Compute the discount a coupon applies to a given subtotal.
     *
     * Thin delegate: since module 36 the single implementation lives in
     * CouponService::compute_discount() so the shop cart, SMM orders, VTU,
     * number rentals, identity checks and gift cards all share one set of
     * maths (PERCENT, the absolute cap, FIXED) and cannot drift apart.
     * Kept public because cartservice->view() and the checkout both call it
     * through this class.
     */
    public function compute_discount($coupon, $subtotal) {
        $this->ci->load->library('CouponService');
        return $this->ci->couponservice->compute_discount($coupon, $subtotal);
    }

    /** The shelf price right now: a valid promotion wins over the list price. */
    private function effective_price($item) {
        return $this->effective_price_of((object)array(
            'price' => $item->current_price,
            'promo_price' => $item->promo_price,
            'currency' => $item->currency ?? marvy_base_currency(),
        ));
    }

    private function effective_price_of($listing) {
        $list = (string)$listing->price;
        $promo = isset($listing->promo_price) && $listing->promo_price !== null ? (string)$listing->promo_price : null;
        $source_amount = ($promo !== null && bccomp($promo, '0', 8) > 0 && bccomp($promo, $list, 8) < 0)
            ? $promo : $list;
        $currency = strtoupper((string)($listing->currency ?? marvy_base_currency()));
        if ($currency === marvy_base_currency()) return $source_amount;
        try {
            $converted = $this->ci->currencyservice->to_base($source_amount, $currency);
            return $converted === null ? null : number_format((float)$converted, 8, '.', '');
        } catch (Throwable $e) {
            log_message('error', 'cart currency conversion failed: '.$e->getMessage());
            return null;
        }
    }

    private function err($code, $message) {
        return array('ok' => false, 'code' => $code, 'error' => $message);
    }
}
