<?php defined('BASEPATH') OR exit('No direct script access allowed');
$perms = $permissions ?? array();
$can_manage = in_array('*', $perms, true) || in_array('payments.manage', $perms, true);
$csrf = function () { return '<input type="hidden" name="'.htmlspecialchars($this->security->get_csrf_token_name())
    .'" value="'.htmlspecialchars($this->security->get_csrf_hash()).'" readonly>'; };
$badge = function ($s) {
    $map = array('SUCCESS'=>'badge-success','PENDING'=>'badge-warning','CREATED'=>'badge-default','FAILED'=>'badge-danger');
    return 'badge '.($map[$s] ?? 'badge-default');
};
$actionable = in_array($tx->status, array('CREATED','PENDING'), true);

// The charge / settlement split (migration 042). `amount`, `fee`, `bonus` and
// `credited_amount` are in the CHARGE currency the gateway was handed; the
// wallet is credited with `credited_base_amount` in the accounting currency,
// at the rate pinned when the deposit was opened. A pre-042 row has no base
// leg because it was charged in the base currency to begin with.
$pay_cur   = strtoupper((string)$tx->currency);
$base_cur  = strtoupper((string)($tx->base_currency ?? $tx->currency));
$credited  = $tx->credited_base_amount ?? ($tx->credited_amount ?? $tx->amount);
$converted = $pay_cur !== $base_cur && !empty($tx->fx_rate);
?>
<div class="row justify-between mb-4" style="align-items:flex-start;flex-wrap:wrap;gap:.75rem">
  <div>
    <a class="text-sm muted" href="<?=site_url('admin/payments')?>">← All payments</a>
    <h2 class="mb-0" style="font-size:1.4rem;font-weight:600">
      Deposit <span class="mono"><?=htmlspecialchars($tx->public_id)?></span>
    </h2>
    <p class="muted text-sm">
      <span class="<?=$badge($tx->status)?>"><?=htmlspecialchars($tx->status)?></span>
      created <?=htmlspecialchars((string)$tx->created_at)?>
    </p>
  </div>
</div>

<?php
  // Reconciliation writes what it found onto the deposit. A short payment in
  // particular must be impossible to miss: the money arrived, it just does not
  // cover the deposit, so nothing was credited and a human has to decide.
  $__meta = json_decode((string)$tx->metadata, true);
  $__recon = is_array($__meta) && !empty($__meta['reconciliation']) ? $__meta['reconciliation'] : null;
?>
<?php if ($__recon && !empty($__recon['underpaid'])): ?>
  <div class="alert alert-warning mb-4">
    <strong>The gateway reports a short payment.</strong>
    <p class="mt-1 mb-0 text-sm">
      Expected <?=marvy_money($__recon['expected'] ?? $tx->amount, $tx->currency)?>,
      the provider reports <?=marvy_money($__recon['provider_amount'] ?? '0', $tx->currency)?>
      (checked <?=htmlspecialchars((string)($__recon['checked_at'] ?? ''))?> UTC).
      Nothing has been credited and the deposit has not been closed. Credit the amount that actually
      arrived by approving it, or reject the deposit and refund the customer at the gateway.
    </p>
  </div>
<?php endif; ?>

<div class="grid grid-2" style="gap:1rem;align-items:start">
  <div class="card">
    <h3 class="text-sm font-semibold mb-2">Deposit</h3>
    <table class="table">
      <tbody>
        <tr><th>Customer</th><td><?=htmlspecialchars((string)$tx->username)?>
            <span class="muted text-xs"><?=htmlspecialchars((string)$tx->email)?></span></td></tr>
        <tr><th>Method</th><td><?=htmlspecialchars((string)$tx->method_name)?>
            <span class="badge badge-default"><?=htmlspecialchars((string)$tx->method_type)?></span></td></tr>
        <tr><th>Amount paid</th><td class="mono"><?=marvy_money($tx->amount, $pay_cur)?></td></tr>
        <tr><th>Fee</th><td class="mono"><?=marvy_money($tx->fee, $pay_cur)?></td></tr>
        <?php if (bccomp((string)$tx->bonus, '0', 8) > 0): ?>
        <tr><th>Bonus</th><td class="mono"><?=marvy_money($tx->bonus, $pay_cur)?></td></tr>
        <?php endif; ?>
        <?php if ($converted): ?>
        <tr><th>Rate (pinned)</th><td class="mono"><?=html_escape(marvy_rate_line($tx->fx_rate, $pay_cur, $base_cur))?></td></tr>
        <?php endif; ?>
        <tr><th>Credits to wallet</th><td class="mono font-bold"><?=marvy_money($credited, $base_cur)?></td></tr>
        <?php if ($tx->provider_tx_id): ?>
        <tr><th>Reference</th><td class="mono text-xs"><?=htmlspecialchars($tx->provider_tx_id)?></td></tr>
        <?php endif; ?>
        <?php if ($tx->verified_at): ?>
        <tr><th>Verified</th><td class="text-xs"><?=htmlspecialchars((string)$tx->verified_at)?></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="card">
    <h3 class="text-sm font-semibold mb-2">Review</h3>
    <?php if (!$can_manage): ?>
      <p class="muted text-sm">You have read-only access to payments.</p>
    <?php elseif ($tx->status === 'SUCCESS'): ?>
      <div class="alert alert-success">
        Credited <?=marvy_money($credited, $base_cur)?> to this customer's wallet.
        Reverse it with a wallet adjustment rather than re-approving.
      </div>
    <?php elseif (!$actionable): ?>
      <div class="alert alert-warning">This deposit is <?=htmlspecialchars($tx->status)?> and cannot be actioned.</div>
    <?php else: ?>
      <p class="text-sm muted mb-2">
        Approving credits <strong><?=marvy_money($credited, $base_cur)?></strong>
        to <?=htmlspecialchars((string)$tx->username)?>'s wallet through the ledger. Confirm the funds
        have actually arrived first — this cannot be undone from here.
      </p>
      <form method="post" action="<?=site_url('admin/payments/'.$tx->public_id.'/approve')?>" class="mb-4"
            data-confirm="Credit <?=htmlspecialchars(marvy_money($credited, $base_cur))?> to this wallet?" >
        <?=$csrf()?>
        <input class="input mb-2" name="provider_tx_id" placeholder="Bank reference (optional)"
               value="<?=htmlspecialchars((string)$tx->provider_tx_id)?>">
        <button class="btn btn-primary btn-sm" type="submit">Approve &amp; credit wallet</button>
      </form>

      <form method="post" action="<?=site_url('admin/payments/'.$tx->public_id.'/reject')?>"
            data-confirm="Reject this deposit? Nothing will be credited." >
        <?=$csrf()?>
        <input class="input mb-2" name="reason" placeholder="Rejection reason">
        <button class="btn btn-secondary btn-sm" type="submit">Reject</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="card mt-4">
  <h3 class="text-sm font-semibold mb-2">Event log</h3>
  <?php if (empty($events)): ?>
    <p class="muted text-sm">No events recorded yet.</p>
  <?php else: ?>
  <div class="overflow-x-auto">
    <table class="table">
      <thead><tr><th>When</th><th>From</th><th>To</th><th>Source</th><th>Reason</th></tr></thead>
      <tbody>
      <?php foreach ($events as $e): ?>
        <tr>
          <td class="text-xs muted"><?=htmlspecialchars((string)$e->created_at)?></td>
          <td class="text-xs"><?=htmlspecialchars((string)($e->from_status ?? '—'))?></td>
          <td><span class="<?=$badge($e->to_status)?>"><?=htmlspecialchars($e->to_status)?></span></td>
          <td class="text-xs"><?=htmlspecialchars((string)$e->source)?></td>
          <td class="text-xs muted"><?=htmlspecialchars((string)($e->reason ?? ''))?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
